<!-- MODAL TAMBAH / EDIT GRUP MENU -->
<?php if (isset($component)) { $__componentOriginalf008eb3693fba0afad2cb07bb34bba19 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalf008eb3693fba0afad2cb07bb34bba19 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.modal-form','data' => ['show' => 'isGroupModalOpen','title' => $groupId ? 'Edit Grup Menu' : 'Tambah Grup Menu','submit' => 'saveGroup','submitText' => 'Simpan Grup','maxWidth' => 'max-w-md']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('modal-form'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['show' => 'isGroupModalOpen','title' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($groupId ? 'Edit Grup Menu' : 'Tambah Grup Menu'),'submit' => 'saveGroup','submitText' => 'Simpan Grup','maxWidth' => 'max-w-md']); ?>
<?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::processComponentKey($component); ?>


    <div>
        <label class="block text-sm font-medium text-slate-400 mb-1">Nama Grup (Header Sidebar)</label>
        <input type="text" wire:model="groupName"
            class="w-full bg-slate-900/50 border border-white/10 text-white rounded-xl px-4 py-2.5 focus:outline-none focus:border-teal-500 uppercase"
            placeholder="Contoh: TRANSAKSI">
        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__errorArgs = ['groupName'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <span class="text-rose-400 text-xs mt-1"><?php echo e($message); ?></span>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
    </div>

    <div>
        <label class="block text-sm font-medium text-slate-400 mb-1">Urutan Tampil</label>
        <input type="number" wire:model="groupOrder"
            class="w-full bg-slate-900/50 border border-white/10 text-white rounded-xl px-4 py-2.5 focus:outline-none focus:border-teal-500">
        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__errorArgs = ['groupOrder'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <span class="text-rose-400 text-xs mt-1"><?php echo e($message); ?></span>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
    </div>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalf008eb3693fba0afad2cb07bb34bba19)): ?>
<?php $attributes = $__attributesOriginalf008eb3693fba0afad2cb07bb34bba19; ?>
<?php unset($__attributesOriginalf008eb3693fba0afad2cb07bb34bba19); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalf008eb3693fba0afad2cb07bb34bba19)): ?>
<?php $component = $__componentOriginalf008eb3693fba0afad2cb07bb34bba19; ?>
<?php unset($__componentOriginalf008eb3693fba0afad2cb07bb34bba19); ?>
<?php endif; ?><?php /**PATH C:\laragon\www\inventory-app\resources\views/livewire/partials/menu-management/modal-group.blade.php ENDPATH**/ ?>