<svg class="w-5 h-5 shrink-0" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" aria-hidden="true" data-slot="icon">
  <path stroke-linecap="round" stroke-linejoin="round" d="M12 4.5v15m7.5-7.5h-15"/>
</svg><?php /**PATH C:\laragon\www\inventory-app\storage\framework\views/b9249f30432a4dc3f07d539e20115b2b.blade.php ENDPATH**/ ?>