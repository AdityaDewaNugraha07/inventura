<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames(([
    'show',
    'title' => 'Form Data',
    'submit' => 'save',
    'submitText' => 'Simpan',
    'maxWidth' => 'max-w-lg',
]));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter(([
    'show',
    'title' => 'Form Data',
    'submit' => 'save',
    'submitText' => 'Simpan',
    'maxWidth' => 'max-w-lg',
]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars, $__key, $__value); ?>

<div x-data="{ open: $wire.entangle('<?php echo e($show); ?>').live }"
     x-show="open"
     x-cloak
     @keydown.escape.window="if (open) open = false"
     class="fixed inset-0 z-50 flex items-center justify-center p-4 overflow-y-auto">

    <!-- Backdrop persis versi asli -->
    <div x-show="open"
         x-transition:enter="ease-out duration-150"
         x-transition:enter-start="opacity-0"
         x-transition:enter-end="opacity-100"
         x-transition:leave="ease-in duration-100"
         x-transition:leave-start="opacity-100"
         x-transition:leave-end="opacity-0"
         @click="open = false"
         class="fixed inset-0 bg-slate-900/60 backdrop-blur-sm">
    </div>

    <!-- Box Modal persis versi asli (bg-slate-800, tanpa garis header & tombol X) -->
    <div x-show="open"
         x-transition:enter="ease-out duration-150"
         x-transition:enter-start="opacity-0 scale-95 translate-y-2"
         x-transition:enter-end="opacity-100 scale-100 translate-y-0"
         x-transition:leave="ease-in duration-100"
         x-transition:leave-start="opacity-100 scale-100 translate-y-0"
         x-transition:leave-end="opacity-0 scale-95 translate-y-2"
         class="relative w-full <?php echo e($maxWidth); ?> max-h-[90vh] overflow-y-auto my-auto bg-slate-800 border border-white/10 shadow-2xl rounded-3xl p-5 sm:p-6 z-10"

        <h3 class="font-bold text-xl text-white mb-6"><?php echo e($title); ?></h3>

        <form wire:submit.prevent="<?php echo e($submit); ?>" class="space-y-4">
            <?php echo e($slot); ?>


            <!-- Footer Tombol persis versi asli -->
            <div class="flex items-center justify-end gap-2 mt-8 border-t border-white/10 pt-6">
                <button type="button" @click="open = false"
                    class="px-6 py-2.5 rounded-xl bg-slate-700 text-white font-medium hover:bg-slate-600 transition-colors cursor-pointer">
                    Batal
                </button>
                <button type="submit" wire:loading.attr="disabled"
                    class="inline-flex items-center gap-2 px-6 py-2.5 rounded-xl bg-gradient-to-r from-teal-500 to-emerald-600 text-white font-semibold shadow-lg hover:shadow-teal-500/50 hover:-translate-y-0.5 transition-all cursor-pointer disabled:opacity-60">
                    <span wire:loading wire:target="<?php echo e($submit); ?>" class="loading loading-spinner loading-xs"></span>
                    <span><?php echo e($submitText); ?></span>
                </button>
            </div>
        </form>
    </div>
</div><?php /**PATH C:\laragon\www\inventory-app\resources\views/components/modal-form.blade.php ENDPATH**/ ?>