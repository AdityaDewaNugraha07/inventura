<svg :class="[open ? 'rotate-180 text-teal-400' : '', collapsed ? 'lg:hidden' : '']" class="w-4 h-4 shrink-0 transition-all duration-300 liquid-ease" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" aria-hidden="true" data-slot="icon">
  <path stroke-linecap="round" stroke-linejoin="round" d="m19.5 8.25-7.5 7.5-7.5-7.5"/>
</svg>